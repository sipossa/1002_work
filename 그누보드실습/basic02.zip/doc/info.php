<?php 
include_once('../../../common.php');
include_once(G5_THEME_PATH.'/head.php'); 
?>


이창훈
<img src="../img/pro01.jpg" alt="">




<?php 
include_once(G5_THEME_PATH.'/tail.php'); 
?>