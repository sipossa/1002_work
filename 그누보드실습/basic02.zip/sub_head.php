<div class="subpage">
    <div class="container">
        <aside>
            <h2>menu</h2>
            <ul>
                <li><a href="<?php echo G5_THEME_URL ?>/doc/info.php">에어 샌드위치메쉬</a></li>
                <li><a href="<?php echo G5_THEME_URL ?>/doc/info.php">면직물(CANVAS)</a></li>
                <li><a href="<?php echo G5_THEME_URL ?>/doc/info.php">회사소개</a></li>
                <li><a href="/bbs/board.php?bo_table=gallery">보유장비</a></li>
                <li><a href="/bbs/board.php?bo_table=qa">고객문의</a></li>
            </ul>
        </aside>
        <article>
